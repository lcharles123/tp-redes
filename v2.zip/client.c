#include "common.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <assert.h>


int main(int argc, char **argv) 
{
    //pre condiçoes: 2 args, ip, max 39chars,     porta até 65535
    if (argc != 3 || strlen(argv[1]) > 39 || strlen(argv[2]) > 5) 
        erro("Forma de uso: ./client <ip> <porta>\n");

    int ipv = versao_ip(argv[1]);
    int ret = -1;
    switch(ipv)
    {
        case 4:
        {
            struct sockaddr_in end4; 
            end4.sin_family = AF_INET;
            end4.sin_addr.s_addr = INADDR_ANY;
            end4.sin_port = htons(atoi(argv[2]));
            ret = console((struct sockaddr_storage*)&end4, 4);
            break;
        }
        case 6:
        {
            struct sockaddr_in6 end6;
            end6.sin6_family = AF_INET6;
            end6.sin6_addr = in6addr_any;
            end6.sin6_port = htons(atoi(argv[2]));
            ret = console((struct sockaddr_storage*)&end6, 6);    
            break;
        }
        default: erro("Erro no IP do servidor: não é nem IPv4 nem IPv6");
    }

    return ret;

}

