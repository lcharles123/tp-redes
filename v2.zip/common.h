#ifndef COMM
#define COMM
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>

#define MAXDEX 40

#define ADD 1
#define REMOVE 2 
#define LIST 3
#define EXCHANGE 4
#define KILL 5

#define SUCESSO 0
#define INVALIDO -1
#define CHEIO -2
#define VAZIO -3

/* Ocorreu corrupção de memória quando esta struct é usada,
 envolvendo a função accept(), portanto serão usadas variáveis comuns */
typedef struct Pokedex
{
    char pokemons[40][11];
    int tam;
    int quantidade;
}Pokedex;


/** Imprime msg e chama exit(EXIT_FAILURE) */
void erro(char *msg);

/** Recebe a mensagem crua em msg, retorna o comando a ela associado e o valor por referencia, se houver */
int tratar_mensagem(char *msg, char nomes[4][11]);

int executar_operacao(char pokemons[][11], int* quantidade, int COMANDO, char nomes[4][11], int n[4]);




int console(struct sockaddr_storage* end, int v);

int versao_ip(const char *src);


#endif

