#include "common.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <assert.h>
#include <netinet/in.h>


int main(int argc, char **argv) 
{
    //pre condiçoes: 2 args, v4|v6,     porta até 65535
    if (argc != 3 || strlen(argv[1]) != 2 || strlen(argv[2]) > 5) 
         erro("Forma de uso: ./server <v4|v6> <porta>");
    
    int sfd;    
    struct sockaddr_storage* end;

    switch(argv[1][1])
    {
        case '4':
        {
            sfd = socket(AF_INET, SOCK_STREAM, 0);
            struct sockaddr_in end4; 
            end4.sin_family = AF_INET;
            end4.sin_addr.s_addr = INADDR_ANY;
            end4.sin_port = htons(atoi(argv[2]));
            end = (struct sockaddr_storage*) &end4;
            break;
        }
        case '6':
        {
            sfd = socket(AF_INET6, SOCK_STREAM, 0);
            struct sockaddr_in6 end6;
            end6.sin6_family = AF_INET6;
            end6.sin6_addr = in6addr_any;
            end6.sin6_port = htons(atoi(argv[2]));
            end = (struct sockaddr_storage*) &end6;  
            break;
        }
        default: erro("Erro no primeiro parametro - Usar v4 ou v6");
    }
      
    if (sfd == -1) 
        erro("Criar socket - Não foi possível");
    if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &(int){1}, sizeof(1)))
        erro("Configurar socket - Erro de configuração");
    
    if (bind(sfd, (struct sockaddr *)end, sizeof(*end)) < 0)
        erro("bind - Não foi possível ligar o endereço ao socket.");
    if (0 != listen(sfd, 10))
        erro("listen - Não foi possível escutar.");
    
    int tamEnd = sizeof(*end);
    int clienteSfd;
    
    
    char pokemons[MAXDEX][11];
    for(int i = 0; i < MAXDEX; i++) pokemons[i][0] = '\0';
    int quantidade = 0;
    
    setbuf(stdout, NULL);
    
    for(;;) // loop principal para realizar as iterações
    { 
    
    /** a memoria esta sendo corrompida neste bloco **/
        for(int i = 0; i < 4; i++){ printf("antes: [%s] ", pokemons[i]);fflush(stdout);} printf("\n");
        if((clienteSfd = accept(sfd, (struct sockaddr *)end, (socklen_t*)&tamEnd)) < 0 ) 
            erro("accept - Não foi possível aceitar conexão");
        for(int i = 0; i < 4; i++){ printf("depois: [%s] ", pokemons[i]);fflush(stdout);}printf("\n");
        
        char buffer[500];
        for(int i = 0; i < 500; i++) buffer[i] = '\0'; //apagar todo o buffer
        int nBytes = 0;
        
        recv(clienteSfd, &buffer, sizeof(buffer), 0);

        if (nBytes == -1){
            erro("recv - Erro ao ler do socket");}
        else if (nBytes >= 0)
        { 
        /** tratar tudo aqui **/
            char nomes[4][11];
            char resposta[500];
            //resposta[0] = '\0';
            int invalidoChar = 0;
            int COMANDO; 
            printf("recv> %s", buffer);
            for(int i = 0; i < 500; i++)
                if(buffer[i] == '\n') { break; }//ok tudo valido
                else if((buffer[i] < 'a' || buffer[i] > 'z') && buffer[i] != ' '){ invalidoChar = 1; break;  }
            
            if(!invalidoChar) COMANDO = tratar_mensagem(buffer, nomes); 
            else COMANDO = INVALIDO; 
          

        switch(COMANDO)
            {
                case ADD :
                {
                    /*int adicionados[4]; 
                    int res = executar_operacao(pokemons, &quantidade, ADD, nomes, adicionados);
                    
                    for(int i = 0; i < 4; i++) printf("lista>>> [%s] ", pokemons[i]);
                        printf("\n");
                        //assert(0);*/
              /** atribuição para testes , atribuir a, b, c, d **/
                    pokemons[0][0] = 'a';pokemons[1][0] = 'b';pokemons[2][0] = 'c';pokemons[3][0] = 'd';
                    pokemons[0][1] = '\0';pokemons[1][1] = '\0';pokemons[2][1] = '\0';pokemons[3][1] = '\0';
                    break;
                }
                case REMOVE:
                case LIST:
                case EXCHANGE:
                case KILL:
                default:
                    sprintf(resposta, "invalid message\n");
            }
                                
            send(clienteSfd, &resposta, sizeof(resposta), 0);  
        }
        
        close(clienteSfd);
        //buffer[0] = '\0';
    }
    
    
    return 0;
}

