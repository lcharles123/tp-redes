#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <inttypes.h>
#include "common.h"


void erro(char *msg)
{
    printf("\n%s\n", msg);
    exit(EXIT_FAILURE);
}

int tratar_mensagem(char *msg, char nomes[4][11])
{
    switch(msg[0])
    {
        case 'a':
        {
            if(msg[1]=='d'&&msg[2]=='d'&&msg[3]==' '&&msg[4]!='\n')
            {
                const char d[2] = " ";
                char *nome;
               nome = strtok(&msg[4], d);
               int n = 0;
               while(nome != NULL ) 
               {
                  if(n > 3) return INVALIDO; //limites de nomes e qtd
                  sprintf(nomes[n], "%s", nome );
                  n++;
                  nome = strtok(NULL, d);
               }
               if(n) nomes[n-1][strlen(nomes[n-1])-1] = '\0';
               else nomes[n][strlen(nomes[n])-1] = '\0';
               for(int i = 0; i < n; i++) if(strlen(nomes[i]) > 11) return INVALIDO; 

               return ADD;
            }
            else
                return INVALIDO;
        
            break;
        }
        case 'r':
        {            
            if(msg[1]=='e'&&msg[2]=='m'&&msg[3]=='o'&&msg[4]=='v'&&msg[5]=='e'&&msg[6]==' '&&msg[7]!='\n')
            {
                for(int i = 0; i < 11; i++)
                {
                    if(msg[7+i] == '\n')
                    {
                        nomes[0][i] = '\0';
                        break;
                    } 
                    nomes[0][i] = msg[7+i];
                }
                if(strlen(nomes[0]) > 11) return INVALIDO; 
                else return REMOVE; 
            }
            else
                return INVALIDO;
            break;
        }
        case 'l':
        {            
            if(msg[1] == 'i' && msg[2] == 's' && msg[3] == 't' && msg[4] == '\n')
                return LIST;
            else
                return INVALIDO;
            break;
        }
        case 'e':
        {            
            if(msg[1]=='x'&&msg[2]=='c'&&msg[3]=='h'&&msg[4]=='a'&&msg[5]=='n'&&msg[6]=='g'&&msg[7]=='e'&&msg[8]== ' '&&msg[9]!='\n')
            {
                const char d[2] = " ";
                char *nome;
               nome = strtok(&msg[9], d);
               int n = 0;
               while(nome != NULL ) 
               {
                  if(n > 1) return INVALIDO; //limites de 2 nomes
                  sprintf(nomes[n], "%s", nome );
                  n++;
                  nome = strtok(NULL, d);
               }
               if(n != 2) return INVALIDO;
               else nomes[1][strlen(nomes[1])-1] = '\0';
               if(strlen(nomes[0]) > 11 || strlen(nomes[1]) > 11) return INVALIDO; 
               return EXCHANGE;
            }
            else
                return INVALIDO;
        }
        case 'k':
        {
            if(msg[1] == 'i' && msg[2] == 'l' && msg[3] == 'l' && msg[4] == '\n')
                return KILL;
            else
                return INVALIDO;
        }
        default:
            return INVALIDO;
    }
}

int console(struct sockaddr_storage* end, int v)
{
    int sfd;
    for(;;)
    {
        if(v == 4)
            sfd = socket(AF_INET, SOCK_STREAM, 0);
        else
            sfd = socket(AF_INET6, SOCK_STREAM, 0);
        
        if (connect(sfd, (struct sockaddr *)end, sizeof(*end)) < 0) 
            erro("connect - Não foi possível conectar.");
       
        char buffer[500];
        for(int i = 0; i < 500; i++) buffer[i] = '\0'; //apagar todo o buffer para nao dar erro
        printf("> ");
        char c ='0';
        //scanf("%s", buffer);
        for(int i = 0 ; c != '\n'; i++){ scanf("%c", &c); buffer[i] = c; } 
       
        send(sfd , buffer , strlen(buffer) , 0 ); //send
        int kill = 0;
        if(0 == strcmp(buffer, "kill\n")) kill = 1; 
        
        int nBytes = 0;
        int totalBytes = 0;

        nBytes = recv(sfd, &buffer, sizeof(buffer), 0);
    
        if (nBytes == INVALIDO)
            erro("recv - Erro ao ler do socket");
        else if (nBytes >= 0)
            printf("< %s", buffer);
     
        close(sfd);
        if(kill) break;
    }

    return EXIT_SUCCESS;  
}

int versao_ip(const char *src) 
{
    char buf[16];
    if (inet_pton(AF_INET, src, buf))
        return 4;
    else if (inet_pton(AF_INET6, src, buf)) 
        return 6;     
    return INVALIDO;
}

int executar_operacao(char pokemons[40][11], int* quantidade, int COMANDO, char nomes[4][11], int n[4])
{

    switch(COMANDO)
    {
        case ADD:
        {   
            /** atribuição para testes **/
            pokemons[0][0] = 'a';pokemons[1][0] = 'b';pokemons[2][0] = 'c';pokemons[3][0] = 'd';
            pokemons[0][1] = '\0';pokemons[1][1] = '\0';pokemons[2][1] = '\0';pokemons[3][1] = '\0';
                
            return SUCESSO;      
            break;
        }
        case REMOVE:
        
        case LIST:
       
        case EXCHANGE:
        
        default: printf("invalid message");
    }
    return INVALIDO;
}



